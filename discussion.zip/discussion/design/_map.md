# Design Map

> `discussion/design/` 直下のファイル・ディレクトリだけを示す地図。下層や個別設計ファイルを作る場合は、その階層の `_map.md` に詳細を委譲する。

---

## 位置付け

`design/` は、Private 2D Rigging Lab / Prototype の設計論点、設計判断、未決事項、調査待ち、設計が満たすべき検証観点を保持するトピックである。

現在のMVPは Private Authoring-to-Viewer Prototype であり、private GUI editor、private runtime core、private viewer、project-defined model package、validator、AI assistant、demo-safe capture を中心に扱う。

設計文書本文はPrivate Prototype baselineへ用語整理済みである。歴史的なファイル名が残るものもあるが、active designはRoot concept / Root AC / MVP ACに従う。

## 直下のファイル・ディレクトリ

| Path | Role | Status |
|------|------|--------|
| [_map.md](_map.md) | `design/` 直下の入口地図 | Private baselineへ更新済み |
| [initial-design-decisions-and-open-questions.md](initial-design-decisions-and-open-questions.md) | MVP更新前後の設計判断、委任範囲、要調査・要議論事項 | Private baseline語彙へ整理済み |
| [ai-agent-connection-and-technology-stack.md](ai-agent-connection-and-technology-stack.md) | AI assistant 接続方式と技術スタック方針 | Private baseline語彙へ整理済み |
| [module-contract-design-decisions.md](module-contract-design-decisions.md) | module contract design の判断ログ | Private baseline語彙へ整理済み。過去判断は参考 |
| [gpt-5.5-pro-review-001-response.md](gpt-5.5-pro-review-001-response.md) | `memo/gpt-5.5-pro-review/reveiw_001.md` への対応分類と反映結果 | Current response record |
| [module-contract-design-goal.md](module-contract-design-goal.md) | module contract design の到達目標、要求粒度、トレーサビリティ要求 | Private baseline語彙へ整理済み |
| [module-contract-output-format-template.md](module-contract-output-format-template.md) | module contract成果物の共通書式・ファイル別テンプレート | 参考 |
| [module-contracts/](module-contracts/_map.md) | TypeScript + Web 向け contract-first module design 成果物群 | Private baseline語彙へ整理済み |
| [mvp-authoring-runtime/](mvp-authoring-runtime/_map.md) | GUI Editor必須の Authoring-to-Runtime MVP を実装へ進める前に固定すべき縦切り設計文書群 | Private baseline語彙へ整理済み |

## 現在の設計焦点

| 項目 | 状態 |
|------|------|
| MVP縦切り | Private GUI editor -> project-defined package -> private runtime core/viewer -> validator -> AI assistant の一周 |
| Package | project-defined model packageを正にする。Cubism形式は検査・読み込み・変換対象にしない |
| Source import | `layered-character-psd-profile-v1` を汎用layered character art import profileとして採用。Live2D / Cubism import profileではない |
| Runtime / Viewer | private runtime coreをEditor previewとViewerで共有する |
| Validator | package / runtime / rights / provenance / demo-safe capture を構造化reportにする |
| AI | auto-riggingではなく assistant / validator として、dry-run、diff、repair suggestion、provenanceを扱う |
| GPT-5.5 Pro review 001 | P0/P1/P2の反映可能指摘を反映。詳細は [gpt-5.5-pro-review-001-response.md](gpt-5.5-pro-review-001-response.md) |
| Demo / Proposal | Streaming Demo Surface と Live2D Feature Proposal はprivate実装から分離する。専用文書を追加済み |

## 次の行動

1. 実装着手時に、設計文書からmodule contract / testsへ落とす。
2. Demo-safe preflightとproposal reviewを、必要に応じてvalidator/AI assistant設計へ反映する。
3. Future integration boundaryを再開する場合は、別途ユーザー判断でscopeを切る。

## 未決事項

| 項目 | 状態 |
|------|------|
| AI Agent は Editor に接続するか、package に対して外部処理するか | 3層連携としてDraft設計済み。Future integration surface化はMVP外 |
| Runtime は Editor preview と Viewer で同一実装にするか | Shared private runtime coreを共有する方針 |
| GUI Editor の画面仕様としてどの項目を決めるか | Draft設計済み。実装時に詳細化 |
| RigControl構造の技術的正体 | Private Prototype内のproject-defined構造として整理継続 |
| Runtime評価セマンティクスの設計判断 | compositionMode、mask opacity 0、missing texture severity、epsilonPolicy は実装前未決 |
